﻿#include "ressourcewidget.h"
#include "ui_ressource.h"
#include "backend/ressource.h"
#include <QMessageBox>
#include <QFileDialog>
#include <QTextStream>
#include <QDebug>

RessourceWidget::RessourceWidget(QWidget *parent)
    : QWidget(parent), ui(new Ui::RessourceWidget), currentModel(nullptr), isEditingMode(false)
{
    ui->setupUi(this);

    // Setup table for editing
    setupTableEditability();

    // Connect signals for CRUD operations
    connect(ui->addServiceBtn, &QPushButton::clicked, this, &RessourceWidget::onAddRessource);
    connect(ui->btnEditService, &QPushButton::clicked, this, &RessourceWidget::onEditRessource);
    connect(ui->btnDeleteService, &QPushButton::clicked, this, &RessourceWidget::onDeleteRessource);
    
    // Connect search functionality
    connect(ui->searchServices, &QLineEdit::textChanged, this, &RessourceWidget::onSearchRessource);
    
    // Connect export functionality
    connect(ui->exportCsvBtn, &QPushButton::clicked, this, &RessourceWidget::onExportCsv);
    
    // REMOVE the Sort by Name button functionality (as per requirements)
    // We'll hide it or disconnect it
    ui->btnSortByName->setVisible(false); // Hide the old sort button
    
    // Connect table cell changes for inline editing
    connect(ui->clientsTable, &QTableWidget::cellChanged, this, &RessourceWidget::onTableCellChanged);
    
    // Load initial data (will be loaded after DB connection is established)
    // loadRessources();  // Don't load here - DB not ready yet
    
    qDebug() << "RessourceWidget initialized successfully";
}

RessourceWidget::~RessourceWidget()
{
    delete ui;
    if (currentModel) {
        delete currentModel;
    }
}

void RessourceWidget::setupTableEditability()
{
    // Enable sorting by clicking column headers
    ui->clientsTable->setSortingEnabled(true);
    
    // Enable editing on double-click and single-click for selected cells
    ui->clientsTable->setEditTriggers(QAbstractItemView::DoubleClicked | 
                                      QAbstractItemView::SelectedClicked |
                                      QAbstractItemView::AnyKeyPressed);
    
    // Set selection behavior
    ui->clientsTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->clientsTable->setSelectionMode(QAbstractItemView::SingleSelection);
    
    // Enable alternating row colors for better readability
    ui->clientsTable->setAlternatingRowColors(true);
    
    // Set stylesheet for black text and better visibility
    ui->clientsTable->setStyleSheet(
        "QTableWidget {"
        "   color: black;"
        "   background-color: white;"
        "   gridline-color: #d0d0d0;"
        "}"
        "QTableWidget::item {"
        "   color: black;"
        "   padding: 5px;"
        "}"
        "QTableWidget::item:selected {"
        "   background-color: #0078d7;"
        "   color: white;"
        "}"
        "QHeaderView::section {"
        "   background-color: #f0f0f0;"
        "   color: black;"
        "   padding: 5px;"
        "   border: 1px solid #d0d0d0;"
        "   font-weight: bold;"
        "}"
    );
    
    // Adjust column widths
    ui->clientsTable->horizontalHeader()->setStretchLastSection(true);
    
    qDebug() << "Table editability configured";
}

void RessourceWidget::loadRessources()
{
    qDebug() << "================================================";
    qDebug() << "[RessourceWidget::loadRessources] CALLED";
    qDebug() << "================================================";
    
    QVector<Ressource> ressources = Ressource::selectAll();
    qDebug() << "[RessourceWidget::loadRessources] Retrieved" << ressources.size() << "resources from DB";
    
    // Temporarily disconnect cellChanged signal to avoid triggering updates during load
    disconnect(ui->clientsTable, &QTableWidget::cellChanged, this, &RessourceWidget::onTableCellChanged);
    
    qDebug() << "[RessourceWidget::loadRessources] Clearing table...";
    ui->clientsTable->setRowCount(0);
    ui->clientsTable->setColumnCount(7); // ID, Title, Path, Owner, Format, Access, Upload Date
    
    // Set proper headers
    QStringList headers;
    headers << "ID" << "Title" << "Path" << "Owner" << "Format" << "Access" << "Upload Date";
    ui->clientsTable->setHorizontalHeaderLabels(headers);
    qDebug() << "[RessourceWidget::loadRessources] Table headers set";
    
    qDebug() << "[RessourceWidget::loadRessources] Populating table with" << ressources.size() << "rows...";
    
    for (const Ressource &ressource : ressources) {
        int row = ui->clientsTable->rowCount();
        ui->clientsTable->insertRow(row);
        
        qDebug() << "[RessourceWidget::loadRessources] Row" << row << "- ID:" << ressource.idMedia << "Title:" << ressource.title;
        
        // ID column (read-only)
        QTableWidgetItem *idItem = new QTableWidgetItem(QString::number(ressource.idMedia));
        idItem->setFlags(idItem->flags() & ~Qt::ItemIsEditable); // Make ID non-editable
        idItem->setForeground(QBrush(Qt::black)); // Black text
        ui->clientsTable->setItem(row, 0, idItem);
        
        // Titre (editable)
        QTableWidgetItem *titleItem = new QTableWidgetItem(ressource.title);
        titleItem->setForeground(QBrush(Qt::black)); // Black text
        ui->clientsTable->setItem(row, 1, titleItem);
        
        // Type (editable)
        QTableWidgetItem *pathItem = new QTableWidgetItem(ressource.path);
        pathItem->setForeground(QBrush(Qt::black)); // Black text
        ui->clientsTable->setItem(row, 2, pathItem);
        
        // Description (editable)
        QTableWidgetItem *ownerItem = new QTableWidgetItem(ressource.owner);
        ownerItem->setForeground(QBrush(Qt::black)); // Black text
        ui->clientsTable->setItem(row, 3, ownerItem);
        
        // Prix (editable)
        QTableWidgetItem *formatItem = new QTableWidgetItem(ressource.format);
        formatItem->setForeground(QBrush(Qt::black)); // Black text
        ui->clientsTable->setItem(row, 4, formatItem);
        
        // État (editable)
        QTableWidgetItem *accessItem = new QTableWidgetItem(ressource.accessLevel);
        accessItem->setForeground(QBrush(Qt::black)); // Black text
        ui->clientsTable->setItem(row, 5, accessItem);

        // Upload Date (read-only)
        QTableWidgetItem *dateItem = new QTableWidgetItem(ressource.uploadDate.toString("yyyy-MM-dd HH:mm"));
        dateItem->setFlags(dateItem->flags() & ~Qt::ItemIsEditable);
        dateItem->setForeground(QBrush(Qt::black));
        ui->clientsTable->setItem(row, 6, dateItem);
    }
    
    // Reconnect cellChanged signal
    connect(ui->clientsTable, &QTableWidget::cellChanged, this, &RessourceWidget::onTableCellChanged);
    
    qDebug() << "[RessourceWidget::loadRessources] ✅ Table population COMPLETE";
    qDebug() << "[RessourceWidget::loadRessources] Table now has" << ui->clientsTable->rowCount() << "rows";
    qDebug() << "================================================";
}

void RessourceWidget::onAddRessource()
{
    qDebug() << "Adding new ressource...";
    
    // Get values from form fields
    // Note: The UI fields don't match perfectly, so we'll adapt
    QString titre = ui->addServiceIdEdit->text().trimmed();
    QString type = ui->addCategoryCombo->currentText().trimmed();
    QString description = ui->addDescriptionEdit->toPlainText().trimmed();
    QString accessControl = ui->addPriceEdit->text().trimmed(); // Access: private/public/etc
    QString path = ui->addNameEdit->text().trimmed(); // Using name edit for "etat"
    
    // Validation
    if (titre.isEmpty()) {
        QMessageBox::warning(this, "Validation Error", 
                           "Le titre est obligatoire !");
        return;
    }
    
    if (type.isEmpty()) {
        QMessageBox::warning(this, "Validation Error", 
                           "Le type est obligatoire !");
        return;
    }
    
    // Prix is optional, default to 0.0
    // Prix removed - format is now QString
    
    // Create new ressource
    Ressource newRessource;
    // Duplicate title check (case-insensitive)
    {
        QVector<Ressource> existing = Ressource::selectAll();
        for (const Ressource &r : existing) {
            if (r.title.compare(titre, Qt::CaseInsensitive) == 0) {
                QMessageBox::warning(this, "Validation Error", 
                                     "Une ressource avec ce titre existe d\u00e9j\u00e0 !");
                return;
            }
        }
    }
    newRessource.title = titre;
    newRessource.path = type;
    newRessource.owner = description.isEmpty() ? "N/A" : description;
    newRessource.format = QString();  // Optional
    newRessource.accessLevel = accessControl.isEmpty() ? "public" : accessControl;
    
    // Insert into database
    if (Ressource::insert(newRessource)) {
        QMessageBox::information(this, "Succ�s", 
                               " Ressource ajout�e avec succ�s !");
        clearAddForm();
        refreshTable();
        
        // Switch back to management tab
        ui->clientTabWidget->setCurrentIndex(0);
    } else {
        QMessageBox::critical(this, "Erreur", 
                            " �chec de l\'ajout de la ressource !");
    }
}

void RessourceWidget::onEditRessource()
{
    int currentRow = ui->clientsTable->currentRow();
    if (currentRow < 0) {
        QMessageBox::warning(this, "Selection Error", 
                           "Veuillez sélectionner une ressource à modifier !");
        return;
    }
    
    QTableWidgetItem *idItem = ui->clientsTable->item(currentRow, 0);
    if (!idItem) {
        QMessageBox::critical(this, "Error", "Cannot retrieve ID!");
        return;
    }
    
    qint64 ressourceId = idItem->text().toLongLong();
    
    Ressource ressource;
    if (!Ressource::fetchById(ressourceId, ressource)) {
        QMessageBox::critical(this, "Erreur", 
                            "Failed to fetch resource!");
        return;
    }
    
    // Populate form for editing
    ui->addServiceIdEdit->setText(ressource.title);
    ui->addCategoryCombo->setCurrentText(ressource.path);
    ui->addDescriptionEdit->setPlainText(ressource.owner);
    ui->addPriceEdit->setText(ressource.format);
    ui->addNameEdit->setText(ressource.accessLevel);
    
    // Switch to Add tab (which doubles as edit)
    ui->clientTabWidget->setCurrentIndex(1);
    
    // Change mode to editing
    isEditingMode = true;
    
    // Disconnect add button and reconnect for update
    disconnect(ui->addServiceBtn, &QPushButton::clicked, this, &RessourceWidget::onAddRessource);
    connect(ui->addServiceBtn, &QPushButton::clicked, this, [this, ressourceId]() {
        onUpdateRessource(ressourceId);
    });
    
    // Change button text
    ui->addServiceBtn->setText("Mettre � jour");
    
    qDebug() << "Editing ressource ID:" << ressourceId;
}

void RessourceWidget::onUpdateRessource(qint64 ressourceId)
{
    qDebug() << "Updating ressource ID:" << ressourceId;
    
    // Get updated values from form
    QString titre = ui->addServiceIdEdit->text().trimmed();
    QString type = ui->addCategoryCombo->currentText().trimmed();
    QString description = ui->addDescriptionEdit->toPlainText().trimmed();
    QString accessControl = ui->addPriceEdit->text().trimmed(); // Access: private/public/etc
    QString path = ui->addNameEdit->text().trimmed();
    
    // Validation
    if (titre.isEmpty() || type.isEmpty()) {
        QMessageBox::warning(this, "Validation Error", 
                           "Tous les champs obligatoires doivent �tre remplis !");
        return;
    }
    
    // Prix removed - format is now QString // Default price
    
    // Create updated ressource
    Ressource updatedRessource;
    // Duplicate title check for update (allow same title for same record)
    {
        QVector<Ressource> existing = Ressource::selectAll();
        for (const Ressource &r : existing) {
            if (r.idMedia != ressourceId && r.title.compare(titre, Qt::CaseInsensitive) == 0) {
                QMessageBox::warning(this, "Validation Error", 
                                     "Une autre ressource avec ce titre existe d\u00e9j\u00e0 !");
                return;
            }
        }
    }
    updatedRessource.title = titre;
    updatedRessource.path = type;
    updatedRessource.owner = description.isEmpty() ? "N/A" : description;
    updatedRessource.format = QString();  // Optional
    updatedRessource.accessLevel = accessControl.isEmpty() ? "public" : accessControl;
    updatedRessource.idMedia = ressourceId;  // Set the ID for update
    
    // Update in database
    if (Ressource::update(updatedRessource)) {
        QMessageBox::information(this, "Succ�s", 
                               " Ressource mise � jour avec succ�s !");
        clearAddForm();
        refreshTable();
        
        // Switch back to management tab
        ui->clientTabWidget->setCurrentIndex(0);
        
        // Restore add functionality
        disconnect(ui->addServiceBtn, nullptr, this, nullptr);
        connect(ui->addServiceBtn, &QPushButton::clicked, this, &RessourceWidget::onAddRessource);
        ui->addServiceBtn->setText("Add");
        isEditingMode = false;
    } else {
        QMessageBox::critical(this, "Erreur", 
                            " Échec de la mise à jour de la ressource !");
    }
}

void RessourceWidget::onDeleteRessource()
{
    int currentRow = ui->clientsTable->currentRow();
    if (currentRow < 0) {
        QMessageBox::warning(this, "Selection Error", 
                           "Please select a resource to edit!");
        return;
    }
    
    QTableWidgetItem *idItem = ui->clientsTable->item(currentRow, 0);
    if (!idItem) {
        QMessageBox::critical(this, "Error", "Cannot retrieve ID!");
        return;
    }
    
    qint64 ressourceId = idItem->text().toLongLong();
    QString titre = ui->clientsTable->item(currentRow, 1)->text();
    
    // Confirmation dialog
    QMessageBox::StandardButton reply = QMessageBox::question(
        this, "Confirmation",
        QString("�tes-vous s�r de vouloir supprimer cette ressource ?\n\n"
                "Titre: %1\nID: %2").arg(titre).arg(ressourceId),
        QMessageBox::Yes | QMessageBox::No
    );
    
    if (reply == QMessageBox::Yes) {
        if (Ressource::remove(ressourceId)) {
            QMessageBox::information(this, "Succ�s", 
                                   " Ressource supprim�e avec succ�s !");
            refreshTable();
        } else {
            QMessageBox::critical(this, "Erreur", 
                                " �chec de la suppression de la ressource !");
        }
    }
    
    qDebug() << "Delete operation completed for ID:" << ressourceId;
}

void RessourceWidget::onSearchRessource(const QString &keyword)
{
    qDebug() << "Searching for:" << keyword;
    
    if (keyword.isEmpty()) {
        // If search is empty, reload all ressources
        loadRessources();
        return;
    }
    
    // Disconnect cellChanged signal during search
    disconnect(ui->clientsTable, &QTableWidget::cellChanged, this, &RessourceWidget::onTableCellChanged);
    
    ui->clientsTable->setRowCount(0);
    QVector<Ressource> ressources = Ressource::selectAll();
    
    // Filter ressources based on keyword
    for (const Ressource &ressource : ressources) {
        bool matches = false;
        
        if (ressource.title.contains(keyword, Qt::CaseInsensitive) ||
            ressource.path.contains(keyword, Qt::CaseInsensitive) ||
            ressource.owner.contains(keyword, Qt::CaseInsensitive) ||
            ressource.accessLevel.contains(keyword, Qt::CaseInsensitive) ||
            ressource.format.contains(keyword)) {
            matches = true;
        }
        
        if (matches) {
            int row = ui->clientsTable->rowCount();
            ui->clientsTable->insertRow(row);
            
            QTableWidgetItem *idItem = new QTableWidgetItem(QString::number(ressource.idMedia));
            idItem->setFlags(idItem->flags() & ~Qt::ItemIsEditable);
            ui->clientsTable->setItem(row, 0, idItem);
            
            ui->clientsTable->setItem(row, 1, new QTableWidgetItem(ressource.title));
            ui->clientsTable->setItem(row, 2, new QTableWidgetItem(ressource.path));
            ui->clientsTable->setItem(row, 3, new QTableWidgetItem(ressource.owner));
            ui->clientsTable->setItem(row, 4, new QTableWidgetItem(ressource.format));   
            ui->clientsTable->setItem(row, 5, new QTableWidgetItem(ressource.accessLevel));
        }
    }
    
    // Reconnect cellChanged signal
    connect(ui->clientsTable, &QTableWidget::cellChanged, this, &RessourceWidget::onTableCellChanged);
    
    qDebug() << "Search completed, found" << ui->clientsTable->rowCount() << "matches";
}

void RessourceWidget::onTableCellChanged(int row, int column)
{
    // Inline editing: when a cell is edited, update the database
    if (column == 0) {
        // ID column should not be editable, but just in case
        return;
    }
    
    qint64 ressourceId = ui->clientsTable->item(row, 0)->text().toLongLong();
    
    qDebug() << "Cell changed at row" << row << "column" << column << "for ressource ID" << ressourceId;
    
    // Fetch current ressource data
    Ressource ressource;
    if (!Ressource::fetchById(ressourceId, ressource)) {
        QMessageBox::critical(this, "Erreur", 
                            "Impossible de r�cup�rer la ressource !");
        return;
    }
    
    // Update the changed field
    QString newValue = ui->clientsTable->item(row, column)->text();
    
    switch (column) {
        case 1: // Titre
            ressource.title = newValue;
            break;
        case 2: // Type
            ressource.path = newValue;
            break;
        case 3: // Description
            ressource.owner = newValue;
            break;
        case 4: // Prix
        {
            bool ok;
            double prix = newValue.toDouble(&ok);
            if (!ok || prix < 0) {
                QMessageBox::warning(this, "Erreur", 
                                   "Le prix doit �tre un nombre valide !");
                refreshTable(); // Reload to reset invalid value
                return;
            }
            ressource.format = newValue;  // Format is QString now
            break;
        }
        case 5: // État
            ressource.accessLevel = newValue;
            break;
        default:
            return;
    }
    
    // Update in database
    if (Ressource::update(ressource)) {
        qDebug() << " Ressource mise � jour (inline edit)";
        // Optionally show a brief notification
        // QMessageBox::information(this, "Succ�s", " Ressource mise � jour.");
    } else {
        QMessageBox::critical(this, "Erreur", 
                            " �chec de la mise � jour !");
        refreshTable(); // Reload to show correct values
    }
}

void RessourceWidget::onExportCsv()
{
    QString fileName = QFileDialog::getSaveFileName(this, "Export CSV", 
                                                    "", "CSV Files (*.csv)");
    if (fileName.isEmpty()) {
        return;
    }
    
    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Erreur", 
                            "Impossible de cr�er le fichier !");
        return;
    }
    
    QTextStream out(&file);
    out << "ID,Titre,Type,Description,Prix,État\n";
    
    QVector<Ressource> ressources = Ressource::selectAll();
    for (const Ressource &ressource : ressources) {
        out << ressource.idMedia << ","
            << "\"" << ressource.title << "\","
            << "\"" << ressource.path << "\","
            << "\"" << ressource.owner << "\","
            << ressource.format << ","
            << "\"" << ressource.accessLevel << "\"\n";
    }
    
    file.close();
    QMessageBox::information(this, "Succ�s", 
                           " Donn�es export�es avec succ�s !");
    
    qDebug() << "Exported" << ressources.size() << "ressources to CSV";
}

void RessourceWidget::clearAddForm()
{
    ui->addServiceIdEdit->clear();
    ui->addNameEdit->clear();
    ui->addDescriptionEdit->clear();
    ui->addCategoryCombo->setCurrentIndex(0);
    ui->addPriceEdit->clear();
    
    qDebug() << "Add form cleared";
}

void RessourceWidget::refreshTable()
{
    qDebug() << "Refreshing table...";
    loadRessources();
}





